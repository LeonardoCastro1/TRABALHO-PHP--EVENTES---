<!DOCTYPE html>
<html>
<head>
  <script src="vendor/tinymce/tinymce.min.js"></script>
  <script>tinymce.init({
      selector:'#myEditor',
      height: 500,
      menubar: true,
      plugins: [
        'advlist autolink lists link image charmap print preview anchor textcolor',
        'searchreplace visualblocks code fullscreen',
        'insertdatetime media table contextmenu paste code help wordcount'
      ],
      toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help'
    });</script>
</head>
<body>

<form action="/" method="post">
  <input type="hidden" name="controller" value="home"/>
  <input type="hidden" name="action" value="dump"/>
  <textarea id="myEditor" name="text">Next, use our Get Started docs to <b>setup</b> Tiny!</textarea>
  <input type="submit"/>
</form>

</body>
</html>
