<?php
  require_once "../bootstrap.php";
  // use App\Controllers\HomeController;
  // $controller = new HomeController();
  // echo $controller->dump();
  // var_dump($current);

  // use App\Services\Database;
  // $db = new Database($current);
  // var_dump($db);



  $action = "index";
  $pController = fromGet("controller");
  $pAction = fromGet("action");
  $action = (isset($pAction)?$pAction:$action);
  $controller = App\Util\ControllerFactory::createController($pController);
  $ret =  $controller->$action();
  $view = "../app/Views/{$ret}.php";
  $_SESSION["view"] = $view;
  require_once "layout/template.php";

  //$controller = ControllerFactory::createController($controllerName);
?>
