<?php

namespace App;

class Configuration{

  public $host;
  public $database;
  public $user;
  public $password;

  function __construct($host, $database, $user, $password){
      $this->host = $host;
      $this->database = $database;
      $this->user = $user;
      $this->password = $password;
  }

}
