<?php echo App\Util\NavbarRender::navbarDeslogado(); ?>


<main role="main" class="container">
  <section>
    <div class="row">
      <div class="col-sm-12 center ">
        <h1>Escolha os Minicursos que deseja fazer</h1>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-12 center ">
        <?php
          $model = fromSession("model");
          echo App\Util\Renderer::renderMinicursosList($model);
        ?>
      </div>
    </div>

  </section>



</main>
