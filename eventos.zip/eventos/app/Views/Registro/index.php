<?php echo App\Util\NavbarRender::navbarDeslogado(); ?>


<main role="main" class="container">

  <div class="row justify-content-sm-center mt-20">
    <div class="col-sm-8">
      <?php
      if (isset($_SESSION['erro'])) {
        echo fromSession("erro");
      }
      ?>
      <div class="card">
        <div class="card-header center">
          <h5><b>Registre-se</b></h5>
        </div>
        <div class="card-body">
          <form  action="?controller=Registro&action=capturaPost" method="post">
            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <label for="InpNome">Informe seu Nome</label>
                  <input type="text" class="form-control" name="InpNome" id="InpNome" placeholder="Informe seu Nome" required>
                </div>
              </div>

            </div>

            <div class="row">
              <div class="col-sm-7">
                <div class="form-group">
                  <label for="InpEmail">Informe seu E-mail</label>
                  <input type="email" class="form-control" name="InpEmail" id="InpEmail" placeholder="Informe seu E-mail" required>
                </div>
              </div>
              <div class="col-sm-5">
                <div class="form-group">
                  <label for="InpPerfil">Você é?</label>
                  <select class="form-control" name="InpPerfil" id="InpPerfil" required>
                    <option value="estudante">Estudante</option>
                    <option value="professor">Professor</option>
                    <option value="visitante">Visitante</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpSexo">Informe seu Sexo</label>
                  <select class="form-control" name="InpSexo" id="InpSexo" required>
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                    <option value="I">Indefinido</option>
                  </select>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpDtNasc">Data de Nascimento</label>
                  <input type="date" class="form-control" name="InpDtNasc" id="InpDtNasc" required>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpTel">Informe seu Telefone</label>
                  <input type="text" class="form-control" name="InpTel" id="InpTel" placeholder="Informe seu Telefone" required>
                </div>
              </div>

            </div>





            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="InpCpf">Informe seu CPF</label>
                  <input type="text" class="form-control" name="InpCpf" id="InpCpf" placeholder="Informe seu CPF" required>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="InpRg">Informe seu RG</label>
                  <input type="text" class="form-control" name="InpRg" id="InpRg" placeholder="Informe seu RG" required>
                </div>
              </div>
            </div>

            <div class="row">


            </div>



            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <label for="InpEndereco">Informe seu Endereço</label>
                  <input type="text" class="form-control" name="InpEndereco" id="InpEndereco" placeholder="Informe seu Endereço" required>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-8">
                <div class="form-group">
                  <label for="InpCidade">Informe sua Cidade</label>
                  <input type="text" class="form-control" name="InpCidade" id="InpCidade" placeholder="Informe sua Cidade" required>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpEstado">Informe seu Estado</label>
                  <select class="form-control" name="InpEstado" id="InpEstado" required>
                    <option value="">ESTADO</option>
                    <option value="AC">AC</option>
                    <option value="AL">AL</option>
                    <option value="AP">AP</option>
                    <option value="AM">AM</option>
                    <option value="BA">BA</option>
                    <option value="CE">CE</option>
                    <option value="DF">DF</option>
                    <option value="ES">ES</option>
                    <option value="GO">GO</option>
                    <option value="MA">MA</option>
                    <option value="MT">MT</option>
                    <option value="MS">MS</option>
                    <option value="MG">MG</option>
                    <option value="PA">PA</option>
                    <option value="PB">PB</option>
                    <option value="PR">PR</option>
                    <option value="PE">PE</option>
                    <option value="PI">PI</option>
                    <option value="RJ">RJ</option>
                    <option value="RN">RN</option>
                    <option value="RS">RS</option>
                    <option value="RO">RO</option>
                    <option value="RR">RR</option>
                    <option value="SC">SC</option>
                    <option value="SP">SP</option>
                    <option value="SE">SE</option>
                    <option value="TO">TO</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpUsername">Informe seu Username</label>
                  <input type="text" class="form-control" name="InpUsername" id="InpUsername" placeholder="Informe seu Username" required>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpSenha">Informe sua Senha</label>
                  <input type="password" class="form-control" name="InpSenha" id="InpSenha" placeholder="Informe sua Senha" required>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="form-group">
                  <label for="InpSenhaConfirm">Confirme sua Senha</label>
                  <input type="password" class="form-control" name="InpSenhaConfirm" id="InpSenhaConfirm" placeholder="Confirme sua Senha" required>
                </div>
              </div>

            </div>
        </div>
        <div class="card-footer">
          <div class="col-sm-12 center">
            <input class="btn btn-success" type="submit" value="Confirmar">
          </div>
        </div>
        </form>
      </div>

    </div>
  </div>

</main>
