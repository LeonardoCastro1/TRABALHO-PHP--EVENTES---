<?php  echo App\Util\NavbarRender::navbarDeslogado(); ?>



<main role="main" class="container">

  <div class="row mt-4 ">
    <div class="col-lg-12">
      <div class="container">

        <div class="col-lg-12 center">
          <h1>Grade de Palestras</h1>
        </div>
        <?php
          $model = fromSession("model");
          echo App\Util\Renderer::renderPalestrantes($model);
        ?>
        </div>
      </div>
    </div>
  </div>

</main>
