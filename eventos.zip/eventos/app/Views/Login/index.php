<?php echo App\Util\NavbarRender::navbarDeslogado(); ?>


<main role="main" class="container">
  <div class="row justify-content-sm-center mt-20">
    <div class="col-sm-6">
      <div class="card text-center">
        <div class="card-header">
          <h5><b>Realizar Login</b></h5>
        </div>
        <div class="card-body">

          <form  action="" method="post">
            <div class="row justify-content-sm-center">
              <div class="col-sm-10">
                <div class="form-group">
                  <label for="InpUsername">Username</label>
                  <input type="text" class="form-control" name="InpUsername" id="InpUsername"  placeholder="Informe seu username">
                </div>
              </div>

              <div class="col-sm-10">
                <div class="form-group">
                  <label for="InpPassword">Senha</label>
                  <input type="password" class="form-control" name="InpPassword" id="InpPassword"  placeholder="Informe sua senha">
                </div>
              </div>

              <div class="col-sm-6">
                <input type="button" class="btn btn-outline-danger btn-block" name="InpBtnLogin" value="Logar-se">
              </div>
            </div>
          </form>


        </div>

      </div>
    </div>
  </div>
</main>
