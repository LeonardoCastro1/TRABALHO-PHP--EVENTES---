<?php echo App\Util\NavbarRender::navbarDeslogado(); ?>

<main role="main" class="container">
  <div class="row">
    <div class="col-lg-12 imgHome">
      <div class="row">
        <div class="col-sm-4 center mt-5">
          <h1 class="titulo">BearTech 2018</h1>
        </div>
      </div>

      <div class="row justify-content-sm-right">
        <div class="col-sm-2 center">
          <a href="?controller=Login&action=index" class="btn btn-danger btn-block">Logar</a>
        </div>
        <div class="col-sm-2">
          <a href="?controller=Registro&action=index" class="btn btn-outline-danger btn-block">Registre-se</a>
        </div>
      </div>
    </div>
  </div>

  <section class="mt-10">
    <div class="row justify-content-sm-center">
      <div class="col-sm-8 center">
        <h1 class="titulo">O que é BearTech?</h1>
      </div>


      <div class="col-sm-10 justify conteudo">
        A BearTech nasceu em 2016 por meio de uma parceria entre o  Urso Pooh, o Zé Colméia e Po com intuito de fomentar a inovação e a tecnologia na região.
        O Objetivo da feira é proporcionar aos participantes uma experiência imersiva para aprendizados de alto impacto e geração de negócios a partir de três pilares: Inovação, tecnologia e empreendedorismo, promovendo assim o desenvolvimento do Norte Pioneiro do Paraná.
      </div>
    </div>
  </section>


  <section>
    <div class="row justify-content-sm-center mt-5">
      <div class="col-sm-8 center">
        <h1 class="titulo">Programação</h1>
      </div>
    </div>

    <div class="row justify-content-sm-center mt-5">
      <div class="col-sm-2 center conteudo">
        <h1><i class="far fa-clock"></i></h1>
        <span><b>100</b><i class="fas fa-plus"></i></span>
        <p>Horas Atividade</p>
      </div>

      <div class="col-sm-2 center conteudo">
        <h1><i class="fas fa-graduation-cap"></i></h1>
        <span><b>8</b><i class="fas fa-plus"></i></span>
        <p>Minicursos</p>
      </div>

      <div class="col-sm-2 center conteudo">
        <h1><i class="fas fa-bullhorn"></i></h1>
        <span><b>15</b><i class="fas fa-plus"></i></span>
        <p>Palestras</p>
      </div>

    </div>
  </section>

  <section>
    <div class="row justify-content-sm-center mt-5">
      <div class="col-sm-8 center">
        <h1 class="titulo">Nossos Patrocinadores</h1>
      </div>
    </div>

    <div class="row justify-content-sm-center mt-3">
      <div class="col-sm-2 center">
        <img src="assets/images/cocacola.jpg" width="120px">
      </div>
      <div class="col-sm-2 center">
        <img src="assets/images/firefox.png" width="120px">
      </div>
      <div class="col-sm-2 center">
        <img src="assets/images/linux.png" width="120px">
      </div>
      <div class="col-sm-2 center">
        <img src="assets/images/redhat.png" width="150px">
      </div>
    </div>
  </section>


  <section>
    <div class="row justify-content-sm-center mt-5">
      <div class="col-sm-8 center">
        <h1 class="titulo">Localização</h1>
      </div>

      <div class="col-sm-12 mt-2 mb-2">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3565.252949138183!2d-50.361870370415026!3d-23.107240793931553!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1spt-BR!2sbr!4v1543954336636" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
    </div>
  </section>


  <section>
    <div class="row justify-content-sm-center mt-5">
      <div class="col-sm-8 center">
        <h1 class="titulo">Fale Conosco</h1>
      </div>





      <div class="col-sm-8 mt-2 mb-2">

        <div class="card" >
          <div class="card-header center">
           <h5> <b>Ente em contato</b> </h5>
          </div>
          <div class="card-body">
            <form action="" method="post">
              <div class="form-group">
                <label for="InpEmail">Email</label>
                <input type="email" name="InpEmail" class="form-control" id="InpEmail"  placeholder="Informe seu email">
                <small id="InpEmail" class="form-text text-muted">Digite seu email de contato</small>
              </div>

              <div class="form-group">
                <label for="InpNome">Nome Completo</label>
                <input type="email" name="InpNome" class="form-control" id="InpNome"  placeholder="Informe seu nome">
                <small id="InpNome" class="form-text text-muted">Digite seu nome completo</small>
              </div>
              <div class="form-group">
                <label for="inpTextContato">Transcreva o que você tem a nos dizer!!!</label>
                <textarea class="form-control" name="inpTextContato" id="inpTextContato" rows="4"></textarea>
              </div>

              <div class="form-group center">
                <input type="button" class="btn btn-outline-success" id="btnEnviarContato" name="btnEnviarContato" value="enviar">
              </div>

            </form>
          </div>
        </div>


      </div>
    </div>
  </section>







</main>
