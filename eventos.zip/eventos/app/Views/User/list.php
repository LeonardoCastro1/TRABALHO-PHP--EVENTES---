<?php
  echo App\Util\NavbarRender::navbarDeslogado();
  $model = $_SESSION['model'];
?>

<main role="main" class="container">
  <h1>User List (View)</h1>

  <?php echo App\Util\Renderer::renderUserTable($model);?>
</main>
