<!-- <header>

  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark fontsize">
    <a class="navbar-brand" href="#"> <img class="img-fluid" src="../public_html/assets/images/beartechsemfundo.png" width="64px"> </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="?controller=Home&action=index">Sobre </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?controller=Palestras&action=index">Palestras</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?controller=Minicurso&action=index">Mnicurso</a>
        </li>
      </ul>
      <div class="form-inline mt-2 mt-md-0">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item ">
            <a class="nav-link" href="?controller=Login&action=index">Logar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="?controller=Registro&action=index">Registre-se</a>
          </li>

        </ul>

      </div>
    </div>
  </nav>
</header> -->
