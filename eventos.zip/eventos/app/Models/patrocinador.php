<?php
  namespace App\Models;

  class patrocinador{

    private $id_patrocinador;
    private $nome;
    private $imagem;
    private $status;


    public function __construct( $id_patrocinador, $nome, $imagem, $status)
    {
      $this->id_patrocinador = $id_patrocinador;
      $this->nome =$nome;
      $this->imagem = $imagem;
      $this->status = $status;
    }


    /**
     * Get the value of Id Patrocinador
     *
     * @return mixed
     */
    public function getIdPatrocinador()
    {
        return $this->id_patrocinador;
    }

    /**
     * Set the value of Id Patrocinador
     *
     * @param mixed id_patrocinador
     *
     * @return self
     */
    public function setIdPatrocinador($id_patrocinador)
    {
        $this->id_patrocinador = $id_patrocinador;

        return $this;
    }

    /**
     * Get the value of Nome
     *
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of Nome
     *
     * @param mixed nome
     *
     * @return self
     */
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of Imagem
     *
     * @return mixed
     */
    public function getImagem()
    {
        return $this->imagem;
    }

    /**
     * Set the value of Imagem
     *
     * @param mixed imagem
     *
     * @return self
     */
    public function setImagem($imagem)
    {
        $this->imagem = $imagem;

        return $this;
    }

    /**
     * Get the value of Status
     *
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set the value of Status
     *
     * @param mixed status
     *
     * @return self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

}


?>
