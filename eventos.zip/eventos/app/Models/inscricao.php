<?php

  namespace App\Models;

  class inscricao{

    private $id_inscricao;
    private $id_user;
    private $id_minicurso;
    private $data;
    private $status_inscricao;


    function __construct($id_inscricao, $id_user, $id_minicurso, $data, $status_inscricao){
      $this->id_inscricao = $id_inscricao;
      $this->id_user = $id_user;
      $this->id_minicurso = $id_minicurso;
      $this->data = $data;
      $this->status_inscricao = $status_inscricao;
    }


    /**
     * Get the value of Id Inscricao
     *
     * @return mixed
     */
    public function getIdInscricao()
    {
        return $this->id_inscricao;
    }

    /**
     * Set the value of Id Inscricao
     *
     * @param mixed id_inscricao
     *
     * @return self
     */
    public function setIdInscricao($id_inscricao)
    {
        $this->id_inscricao = $id_inscricao;

        return $this;
    }

    /**
     * Get the value of Id User
     *
     * @return mixed
     */
    public function getIdUser()
    {
        return $this->id_user;
    }

    /**
     * Set the value of Id User
     *
     * @param mixed id_user
     *
     * @return self
     */
    public function setIdUser($id_user)
    {
        $this->id_user = $id_user;

        return $this;
    }

    /**
     * Get the value of Id Minicurso
     *
     * @return mixed
     */
    public function getIdMinicurso()
    {
        return $this->id_minicurso;
    }

    /**
     * Set the value of Id Minicurso
     *
     * @param mixed id_minicurso
     *
     * @return self
     */
    public function setIdMinicurso($id_minicurso)
    {
        $this->id_minicurso = $id_minicurso;

        return $this;
    }

    /**
     * Get the value of Data
     *
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * Set the value of Data
     *
     * @param mixed data
     *
     * @return self
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }

    /**
     * Get the value of Status Inscricao
     *
     * @return mixed
     */
    public function getStatusInscricao()
    {
        return $this->status_inscricao;
    }

    /**
     * Set the value of Status Inscricao
     *
     * @param mixed status_inscricao
     *
     * @return self
     */
    public function setStatusInscricao($status_inscricao)
    {
        $this->status_inscricao = $status_inscricao;

        return $this;
    }

}


?>
