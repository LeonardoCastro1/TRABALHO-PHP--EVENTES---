<?php

  namespace App\Models;

  class palestra{

      private $id_palestra;
      private $nome;
      private $palestrante;
      private $data;
      private $descricao;
      private $horario;


      // public function __construct( $id_palestra, $nome, $palestrante, $data, $tema, $descricao)
      // {
      //   $this->id_palestra = $id_palestra;
      //   $this->nome = $nome;
      //   $this->palestrante = $palestrante;
      //   $this->data = $data;
      //   $this->tema = $tema;
      //   $this->descricao = $descricao;
      // }


      public function __construct()
      {

      }



    /**
     * Get the value of Id Palestra
     *
     * @return mixed
     */
    public function getIdPalestra()
    {
        return $this->id_palestra;
    }

    /**
     * Set the value of Id Palestra
     *
     * @param mixed id_palestra
     *
     * @return self
     */
    public function setIdPalestra($id_palestra)
    {
        $this->id_palestra = $id_palestra;

        return $this;
    }

    /**
     * Get the value of Nome
     *
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of Nome
     *
     * @param mixed nome
     *
     * @return self
     */
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of Palestrante
     *
     * @return mixed
     */
    public function getPalestrante()
    {
        return $this->palestrante;
    }

    /**
     * Set the value of Palestrante
     *
     * @param mixed palestrante
     *
     * @return self
     */
    public function setPalestrante($palestrante)
    {
        $this->palestrante = $palestrante;

        return $this;
    }

    /**
     * Get the value of Data
     *
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * Set the value of Data
     *
     * @param mixed data
     *
     * @return self
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }



    /**
     * Get the value of Descricao
     *
     * @return mixed
     */
    public function getDescricao()
    {
        return $this->descricao;
    }

    /**
     * Set the value of Descricao
     *
     * @param mixed descricao
     *
     * @return self
     */
    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;

        return $this;
    }


        /**
         * Get the value of Horario
         *
         * @return mixed
         */
        public function getHorario()
        {
            return $this->horario;
        }

        /**
         * Set the value of Horario
         *
         * @param mixed horario
         *
         * @return self
         */
        public function setHorario($horario)
        {
            $this->horario = $horario;

            return $this;
        }

}


?>
