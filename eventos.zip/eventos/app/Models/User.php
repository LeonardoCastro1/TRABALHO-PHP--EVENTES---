<?php

  namespace App\Models;

  class User {
    private $id_user;
    private $username;
    private $password;
    private $confirmPassword;
    private $nome;
    private $email;
    private $dtnasc;
    private $cpf;
    private $rg;
    private $endereco;
    private $cidade;
    private $telefone;
    private $estado;
    private $perfil;
    private $sexo;




    // function __construct($username,$password ,$nome, $email, $dtnasc, $cpf, $rg, $endereco, $cidade, $telefone, $estado, $perfil, $sexo){
    //   $this->username = $username;
    //   $this->password = $password;
    //   $this->nome = $nome;
    //   $this->email = $email;
    //   $this->dtnasc = $dtnasc;
    //   $this->cpf = $cpf;
    //   $this->rg = $rg;
    //   $this->endereco = $endereco;
    //   $this->cidade = $cidade;
    //   $this->telefone = $telefone;
    //   $this->estado = $estado;
    //   $this->perfil = $perfil;
    //   $this->sexo = $sexo;
    //
    // }

    public function __construct()
    {

    }


    // --- GET AND SET username --- //
    public function getUsername(){
        return $this->username;
    }


    public function setUsername($username){
        $this->username = $username;
        return $this;
    }


    // --- GET AND SET password --- //
    public function getPassword(){
      return $this->password;
    }

    public function setPassword($password){
      $this->password = $password;
      return $this;
    }


    // --- GET AND SET nome --- //
    public function getNome(){
        return $this->nome;
    }


    public function setNome($nome){
        $this->nome = $nome;
        return $this;
    }


    // --- GET AND SET email --- //
    public function getEmail(){
        return $this->email;
    }


    public function setEmail($email){
        $this->email = $email;
        return $this;
    }


    // --- GET AND SET dtnasc --- //
    public function getDtnasc(){
        return $this->dtnasc;
    }


    public function setDtnasc($dtnasc){
        $this->dtnasc = $dtnasc;
        return $this;
    }


    // --- GET AND SET cpf --- //
    public function getCpf(){
        return $this->cpf;
    }


    public function setCpf($cpf){
        $this->cpf = $cpf;
        return $this;
    }


    // --- GET AND SET rg --- //
    public function getRg(){
        return $this->rg;
    }


    public function setRg($rg){
        $this->rg = $rg;
        return $this;
    }



    // --- GET AND SET endereco --- //
    public function getEndereco(){
        return $this->endereco;
    }


    public function setEndereco($endereco){
        $this->endereco = $endereco;
        return $this;
    }


    // --- GET AND SET cidade --- //
    public function getCidade(){
        return $this->cidade;
    }


    public function setCidade($cidade){
        $this->cidade = $cidade;
        return $this;
    }


    // --- GET AND SET telefone --- //
    public function getTelefone(){
        return   $this->telefone;
    }


    public function setTelefone($telefone){
        $this->telefone = $telefone;
        return $this;
    }


    // --- GET AND SET estado --- //
    public function getEstado(){
        return $this->estado;
    }


    public function setEstado($estado){
        $this->estado = $estado;
        return $this;
    }


    // --- GET AND SET perfil --- //
    public function getPerfil(){
        return $this->perfil;
    }


    public function setPerfil($perfil){
        $this->perfil = $perfil;
        return $this;
    }


    // --- GET AND SET sexo --- //
    public function getSexo(){
        return $this->sexo;
    }


    public function setSexo($sexo){
        $this->sexo = $sexo;
        return $this;
    }




    /**
     * Get the value of Id User
     *
     * @return mixed
     */
    public function getIdUser()
    {
        return $this->id_user;
    }

    /**
     * Set the value of Id User
     *
     * @param mixed id_user
     *
     * @return self
     */
    public function setIdUser($id_user)
    {
        $this->id_user = $id_user;

        return $this;
    }

    /**
     * Get the value of Confirm Password
     *
     * @return mixed
     */
    public function getConfirmPassword()
    {
        return $this->confirmPassword;
    }

    /**
     * Set the value of Confirm Password
     *
     * @param mixed confirmPassword
     *
     * @return self
     */
    public function setConfirmPassword($confirmPassword)
    {
        $this->confirmPassword = $confirmPassword;

        return $this;
    }

}
