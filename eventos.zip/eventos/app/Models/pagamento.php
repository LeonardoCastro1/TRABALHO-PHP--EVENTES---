<?php

  namespace App\Models;

  class pagamento{

    private $id_pagamento;
    private $id_usuario;
    private $valor;
    private $dt_venc;
    private $dt_pag;
    private $status_pag;


    public function __construct( $id_pagamento, $id_usuario, $valor, $dt_venc, $dt_pag, $status_pag)
    {
      $this->id_pagamento = $id_pagamento;
      $this->id_usuario = $id_usuario;
      $this->valor = $valor;
      $this->dt_venc = $dt_venc;
      $this->dt_pag = $dt_pag;
      $this->status_pag = $status_pag;
    }


    /**
     * Get the value of Id Pagamento
     *
     * @return mixed
     */
    public function getIdPagamento()
    {
        return $this->id_pagamento;
    }

    /**
     * Set the value of Id Pagamento
     *
     * @param mixed id_pagamento
     *
     * @return self
     */
    public function setIdPagamento($id_pagamento)
    {
        $this->id_pagamento = $id_pagamento;

        return $this;
    }

    /**
     * Get the value of Id Usuario
     *
     * @return mixed
     */
    public function getIdUsuario()
    {
        return $this->id_usuario;
    }

    /**
     * Set the value of Id Usuario
     *
     * @param mixed id_usuario
     *
     * @return self
     */
    public function setIdUsuario($id_usuario)
    {
        $this->id_usuario = $id_usuario;

        return $this;
    }

    /**
     * Get the value of Valor
     *
     * @return mixed
     */
    public function getValor()
    {
        return $this->valor;
    }

    /**
     * Set the value of Valor
     *
     * @param mixed valor
     *
     * @return self
     */
    public function setValor($valor)
    {
        $this->valor = $valor;

        return $this;
    }

    /**
     * Get the value of Dt Venc
     *
     * @return mixed
     */
    public function getDtVenc()
    {
        return $this->dt_venc;
    }

    /**
     * Set the value of Dt Venc
     *
     * @param mixed dt_venc
     *
     * @return self
     */
    public function setDtVenc($dt_venc)
    {
        $this->dt_venc = $dt_venc;

        return $this;
    }

    /**
     * Get the value of Dt Pag
     *
     * @return mixed
     */
    public function getDtPag()
    {
        return $this->dt_pag;
    }

    /**
     * Set the value of Dt Pag
     *
     * @param mixed dt_pag
     *
     * @return self
     */
    public function setDtPag($dt_pag)
    {
        $this->dt_pag = $dt_pag;

        return $this;
    }

    /**
     * Get the value of Status Pag
     *
     * @return mixed
     */
    public function getStatusPag()
    {
        return $this->status_pag;
    }

    /**
     * Set the value of Status Pag
     *
     * @param mixed status_pag
     *
     * @return self
     */
    public function setStatusPag($status_pag)
    {
        $this->status_pag = $status_pag;

        return $this;
    }

}


?>
