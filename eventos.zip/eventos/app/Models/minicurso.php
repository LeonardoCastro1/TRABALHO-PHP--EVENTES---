<?php

  namespace App\Models;



  class minicurso{

    private $id_minicurso;
    private $nome;
    private $instrutor;
    private $data;
    private $horario;
    private $valor;
    private $descricao;
    private $qnt_vagas;
    private $qnt_restante;

    // public function __construct($id_minicurso, $nome, $instrutor, $data, $valor, $tema, $descricao, $qtd_vagas, $qnt_restante)
    // {
    //   $this->id_minicurso = $id_minicurso;
    //   $this->nome = $nome;
    //   $this->instrutor = $instrutor;
    //   $this->data = $data;
    //   $this->valor = $valor;
    //   $this->descricao = $descricao;
    //   $this->qtd_vagas = $qtd_vagas;
    //   $this->qnt_restante = $qnt_restante;
    // }

    public function __construct()
    {

    }

    /**
     * Get the value of Id Minicurso
     *
     * @return mixed
     */
    public function getIdMinicurso()
    {
        return $this->id_minicurso;
    }

    /**
     * Set the value of Id Minicurso
     *
     * @param mixed id_minicurso
     *
     * @return self
     */
    public function setIdMinicurso($id_minicurso)
    {
        $this->id_minicurso = $id_minicurso;

        return $this;
    }

    /**
     * Get the value of Nome
     *
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of Nome
     *
     * @param mixed nome
     *
     * @return self
     */
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of Instrutor
     *
     * @return mixed
     */
    public function getInstrutor()
    {
        return $this->instrutor;
    }

    /**
     * Set the value of Instrutor
     *
     * @param mixed instrutor
     *
     * @return self
     */
    public function setInstrutor($instrutor)
    {
        $this->instrutor = $instrutor;

        return $this;
    }

    /**
     * Get the value of Data
     *
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * Set the value of Data
     *
     * @param mixed data
     *
     * @return self
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }

    /**
     * Get the value of Valor
     *
     * @return mixed
     */
    public function getValor()
    {
        return $this->valor;
    }

    /**
     * Set the value of Valor
     *
     * @param mixed valor
     *
     * @return self
     */
    public function setValor($valor)
    {
        $this->valor = $valor;

        return $this;
    }

    /**
     * Get the value of Descricao
     *
     * @return mixed
     */
    public function getDescricao()
    {
        return $this->descricao;
    }

    /**
     * Set the value of Descricao
     *
     * @param mixed descricao
     *
     * @return self
     */
    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;

        return $this;
    }

    /**
     * Get the value of qnt_vagas
     *
     * @return mixed
     */
    public function getQntVagas()
    {
        return $this->qnt_vagas;
    }

    /**
     * Set the value of qnt_vagas
     *
     * @param mixed qnt_vagas
     *
     * @return self
     */
    public function setQntVagas($qnt_vagas)
    {
        $this->qnt_vagas = $qnt_vagas;

        return $this;
    }

    /**
     * Get the value of Qnt Restante
     *
     * @return mixed
     */
    public function getQntRestante()
    {
        return $this->qnt_restante;
    }

    /**
     * Set the value of Qnt Restante
     *
     * @param mixed qnt_restante
     *
     * @return self
     */
    public function setQntRestante($qnt_restante)
    {
        $this->qnt_restante = $qnt_restante;

        return $this;
    }


    /**
     * Get the value of Horario
     *
     * @return mixed
     */
    public function getHorario()
    {
        return $this->horario;
    }

    /**
     * Set the value of Horario
     *
     * @param mixed horario
     *
     * @return self
     */
    public function setHorario($horario)
    {
        $this->horario = $horario;

        return $this;
    }

}

?>
