<?php

namespace App\Util;

class Renderer{

  public static function renderUserTable($model){
    $str = "<table class=\"table table-stripped\">";
    $str .= "<thead> <th> Nome </th> <th> Usuário </th> <th> E-maio </th></thead>";
    $str .= "<tbody>";
    foreach ($model as $m) {
      $n = $m->getNome();
      $u = $m->getUsername();
      $e = $m->getEmail();
      $str .= "<tr>";
      $str .= "<td>$n</td>";
      $str .= "<td>$u</td>";
      $str .= "<td>$e</td>";
      $str .= "</tr>";
    }
    $str .= "</tbody>";
    $str .= "</table>";
    return $str;
  }


  public static function renderPalestrantesList($palestras){
    $qtd = count($palestras);

    $str ="<div class='col-md-10 col-md-offset-1 mt-3'>";
    $str .=  "<div class='panel-body'>";
    $str .=    "<table class='table table-striped table-bordered table-list center'>";
    $str .=      "<thead>";
    $str .=        "<tr>";
    $str .=          "<th>Titulo</th>";
    $str .=          "<th>Descrição</th>";
    $str .=          "<th>Tema</th>";
    $str .=          "<th>Palestrante</th>";
    $str .=          "<th>Data</th>";
    $str .=          "<th>Horário</th>";
    $str .=        "</tr>";
    $str .=      "</thead>";
    $str .=      "<tbody>";
    for ($i=0; $i<$qtd;$i++) {
      $nome = $palestras[$i]->getNome();
      $palestrante = $palestras[$i]->getPalestrante();
      $data = $palestras[$i]->getData();
      $tema = $palestras[$i]->getTema();
      $descricao = $palestras[$i]->getDescricao();
      $horario = $palestras[$i]->getHorario();
      $str .= "<tr>";
      $str .=   "<td>$nome</td>";
      $str .=   "<td>$descricao</td>";
      $str .=   "<td>$tema</td>";
      $str .=   "<td>$palestrante</td>";
      $str .=   "<td>$data</td>";
      $str .=   "<td>$horario</td>";
      $str .= "</tr>";

    }
    $str .=      "</tbody>";
    $str .=    "</table>";
    $str .=    "</div>";
    $str .=  "</div>";
    return $str;
  }


  public static function renderMinicursosList($minicursos){
    // $qtd = count($minicursos);
    //
    // $str ="<div class='col-md-10 col-md-offset-1 mt-3'>";
    // $str .=  "<div class='panel-body'>";
    // $str .=    "<table class='table table-striped table-bordered table-list center'>";
    // $str .=      "<thead>";
    // $str .=        "<tr>";
    // $str .=          "<th>Titulo</th>";
    // $str .=          "<th>Descrição</th>";
    // $str .=          "<th>Instrutor</th>";
    // $str .=          "<th>Data</th>";
    // $str .=          "<th>Horário</th>";
    // $str .=          "<th>Valor</th>";
    // $str .=          "<th>Vagas Restantes</th>";
    // $str .=        "</tr>";
    // $str .=      "</thead>";
    // $str .=      "<tbody>";
    // for ($i=0; $i<$qtd;$i++) {
    //   $nome = $minicursos[$i]->getNome();
    //   $instrutor = $minicursos[$i]->getInstrutor();
    //   $data = $minicursos[$i]->getData();
    //   $descricao = $minicursos[$i]->getDescricao();
    //   $valor = $minicursos[$i]->getValor();
    //   $qnt_restante = $minicursos[$i]->getQntRestante();
    //   $horario = $minicursos[$i]->getHorario();
    //
    //   $str .= "<tr>";
    //   $str .=   "<td>$nome</td>";
    //   $str .=   "<td>$descricao</td>";
    //   $str .=   "<td>$instrutor</td>";
    //   $str .=   "<td>$data</td>";
    //   $str .=   "<td>$horario</td>";
    //   $str .=   "<td>$valor</td>";
    //   $str .=   "<td>$qnt_restante</td>";
    //   $str .= "</tr>";
    //
    // }
    // $str .=      "</tbody>";
    // $str .=    "</table>";
    // $str .=    "</div>";
    // $str .=  "</div>";
    // return $str;

    $qtd = count($minicursos);

    $str = "<div class='container'>";
    $str .= 	"<div class='row justify-content-sm-center'>";

    for ($i=0; $i<$qtd;$i++) {
      $nome = $minicursos[$i]->getNome();
      $instrutor = $minicursos[$i]->getInstrutor();
      $data = $minicursos[$i]->getData();
      $descricao = $minicursos[$i]->getDescricao();
      $valor = $minicursos[$i]->getValor();
      $qnt_restante = $minicursos[$i]->getQntRestante();
      $horario = $minicursos[$i]->getHorario();

      $str .="<div class='card bg-light mb-3 mg-2' style='max-width: 18rem;'>";
      $str .=  "<div class='card-header text-center'>".$nome."</div>";
  		$str .=	 "<div class='card-body'>";
  		$str .=		 "<span class='card-text'>".$descricao."</span>";
      $str .=	 "</div>";
      $str .=  "<div class='card-footer'><span>Data: ".date('d/m/Y', strtotime($data))."  -  Hora: ".$horario."</span><br/><span>Valor: ".$valor."    Vagas Restantes: ".$qnt_restante."</span></div>";
  		$str .="</div>";

    }


    return $str;
  }

  public static function renderPalestrantes($palestras){
    $qtd = count($palestras);

    $str = "<div class='container'>";
    $str .= 	"<div class='row justify-content-sm-center'>";
    for ($i=0; $i<$qtd;$i++) {
      $nome = $palestras[$i]->getNome();
      $palestrante = $palestras[$i]->getPalestrante();
      $data = $palestras[$i]->getData();
      $descricao = $palestras[$i]->getDescricao();
      $horario = $palestras[$i]->getHorario();

      $str .="<div class='card bg-light mb-3 mg-2' style='max-width: 18rem;'>";
      $str .=  "<div class='card-header text-center'>".$nome."</div>";
  		$str .=	 "<div class='card-body'>";
  		$str .=		 "<span class='card-text'>".$descricao."</span>";
      $str .=	 "</div>";
      $str .=  "<div class='card-footer'><span>Data: ".date('d/m/Y', strtotime($data))."  -  Hora: ".$horario."</div>";
  		$str .="</div>";
    }
    return $str;
  }


}
