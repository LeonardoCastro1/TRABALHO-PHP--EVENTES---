<?php

namespace App\Util;

class ControllerFactory {
  public static function createController($pController){
    $controllerName = (isset($pController)?$pController:"Home");
    $ns = "App\Controllers\\";
    $controllerName = $ns.$controllerName."Controller";
     // echo "<script>console.log( 'ControllerFactory: " . $controllerName . "' );</script>";
    $controller = new $controllerName();
    return $controller;
  }
}
