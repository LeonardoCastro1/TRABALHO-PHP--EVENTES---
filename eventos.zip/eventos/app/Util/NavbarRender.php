<?php

  namespace App\Util;

  class NavbarRender{

    public function navbarDeslogado(){
    echo " <header>";
    echo    "<!-- Fixed navbar -->";
    echo    "<nav class='navbar navbar-expand-md navbar-dark fixed-top bg-dark fontsize'>";
    echo      "<a class='navbar-brand' href='?controller=Home&action=index'> <img class='img-fluid' src='../public_html/assets/images/beartechsemfundo.png' width='64px'> </a>";
    echo      "<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarCollapse' aria-controls='navbarCollapse' aria-expanded='false' aria-label='Toggle navigation'>";
    echo        "<span class='navbar-toggler-icon'></span>";
    echo      "</button>";
    echo      "<div class='collapse navbar-collapse' id='navbarCollapse'>";
    echo        "<ul class='navbar-nav mr-auto'>";
    echo          "<li class='nav-item'>";
    echo            "<a class='nav-link' href='?controller=Home&action=index'>Home</a>";
    echo          "</li>";
    echo          "<li class='nav-item'>";
    echo            "<a class='nav-link' href='?controller=Palestras&action=index'>Palestras</a>";
    echo         " </li>";
    echo          "<li class='nav-item'>";
    echo            "<a class='nav-link' href='?controller=Minicurso&action=index'>Minicurso</a>";
    echo          "</li>";
    echo        "</ul>";
    echo        "<div class='form-inline mt-2 mt-md-0'>";
    echo          "<ul class='navbar-nav mr-auto'>";
    echo            "<li class='nav-item '>";
    echo              "<a class='nav-link' href='?controller=Login&action=index'>Logar</a>";
    echo           " </li>";
    echo            "<li class='nav-item'>";
    echo              "<a class='nav-link' href='?controller=Registro&action=index'>Registre-se</a>";
    echo            "</li>";

    echo          "</ul>";

    echo       " </div>";
    echo      "</div>";
    echo    "</nav>";
    echo  "</header>";
    }
  }

?>
