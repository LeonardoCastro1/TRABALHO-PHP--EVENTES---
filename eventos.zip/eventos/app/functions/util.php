<?php

  function fromGet($param){
    if(isset($_GET[$param])) {
      return $_GET[$param];
    }
  }

  function fromSession($param){
    $value = $_SESSION[$param];
    unset($_SESSION[$param]);
    return $value;
  }

  function loadView(){
    $view = fromSession("view");
    require $view;
  }


  function sanitize($string, $conn){
   $string = $conn->real_escape_string($string);
   $string = htmlentities($string);
   return $string;
}

function sanitize_unsafe($value) {
   $search = array("\\",  "\x00", "\n",  "\r",  "'",  '"', "\x1a");
   $replace = array("\\\\","\\0","\\n", "\\r", "\'", '\"', "\\Z");
   return str_replace($search, $replace, $value);
}

function fromPost($var){
    if (isset($_POST[$var]))
      return sanitize_unsafe($_POST[$var]);
}

function _fromGet($var){
   if (isset($_GET[$var]))
      return sanitize_unsafe($_GET[$var]);
}

function isValid($var) {
   return !empty(trim($var));
}

function getHtml($tag, $value="", $attr=""){
    return "<$tag $attr>$value</$tag>";
}

function li($value){
     return getHtml("li",$value);
}

function ul($value){
     return getHtml("ul",$value);
 }

 function validaCPF($cpf) {

 // Verifica se um número foi informado
 if(empty($cpf)) {
   return false;
 }

 // Elimina possivel mascara
 $cpf = preg_replace("/[^0-9]/", "", $cpf);
 $cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);

 // Verifica se o numero de digitos informados é igual a 11
 if (strlen($cpf) != 11) {
   return false;
 }
 // Verifica se nenhuma das sequências invalidas abaixo
 // foi digitada. Caso afirmativo, retorna falso
 else if ($cpf == '00000000000' ||
   $cpf == '11111111111' ||
   $cpf == '22222222222' ||
   $cpf == '33333333333' ||
   $cpf == '44444444444' ||
   $cpf == '55555555555' ||
   $cpf == '66666666666' ||
   $cpf == '77777777777' ||
   $cpf == '88888888888' ||
   $cpf == '99999999999') {
   return false;
  // Calcula os digitos verificadores para verificar se o
  // CPF é válido
  }else {

     for ($t = 9; $t < 11; $t++) {

       for ($d = 0, $c = 0; $c < $t; $c++) {
         $d += $cpf{$c} * (($t + 1) - $c);
       }
       $d = ((10 * $d) % 11) % 10;
       if ($cpf{$c} != $d) {
         return false;
       }
     }

     return true;
   }
 }



 ?>
