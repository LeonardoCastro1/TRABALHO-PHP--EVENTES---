<?php

namespace App\Controllers;
use App\Services\Database;
use App\Services\PalestrasService;



class PalestrasController {

  public function index(){

    $current = fromSession("current");

    $db = new Database($current);
    $result = $db->all("palestra");

    $service = new PalestrasService();
    $palestras = $service->PalestrasList($result);

    $_SESSION['model'] = $palestras;
    $_SESSION['titulo'] = "BearTech Event";
    return "/Palestras/index";

  }

}


?>
