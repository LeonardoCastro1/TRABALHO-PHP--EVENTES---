<?php

namespace App\Controllers;
use App\Services\Database;
use App\Services\MinicursoService;


class MinicursoController {

  public function index(){


    $current = fromSession("current");

    $db = new Database($current);
    $result = $db->all("minicurso");

    $service = new MinicursoService();
    $minicursos = $service->minicursoList($result);

    // echo "<script>console.log( 'Debug Objects: " . $p->getTema() . "' );</script>";
    $_SESSION['model'] = $minicursos;

    $_SESSION['titulo'] = "BearTech Event";
    return "/Minicurso/index";

  }

}


?>
