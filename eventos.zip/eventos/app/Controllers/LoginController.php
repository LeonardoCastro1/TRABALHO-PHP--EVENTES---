<?php

namespace App\Controllers;

class LoginController {

  public function index(){
    $_SESSION['titulo'] = "BearTech Event";
    return "/Login/index";

  }

}


?>
