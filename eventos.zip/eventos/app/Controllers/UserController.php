<?php
namespace App\Controllers;

use App\Models\User;

class UserController {


  public function list(){
    $lst = [
      new User("zezinho", "José da Silva", "jose@uenp.edu.br"),
      new User("manezinho", "Manoela da Silva", "mane@uenp.edu.br")
    ];
    $_SESSION['model'] = $lst;
    return "User/list";
  }

  public function index(){
    return $this->list();
  }
}

?>
