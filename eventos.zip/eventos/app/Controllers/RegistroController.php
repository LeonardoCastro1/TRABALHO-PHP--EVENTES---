<?php

namespace App\Controllers;
use App\Models\User;
use App\Services\RegistroService;
use App\services\MinicursoService;

class RegistroController {

  private $current;

  public function index(){
    $_SESSION['titulo'] = "BearTech Event";
    return "/Registro/index";

  }

  public function registrar($user){
    $cond = false;
    $current = fromSession("current");
    $this->current = $current;
    $_SESSION['titulo'] = "BearTech Event";
    $registroService = new RegistroService();
    $cond = $registroService->validaUser($user);
    $cond = $registroService->verificaExiste($user, $current);

    if ($cond) {
      $_SESSION['erro'] = ul(li("Olá Caro amigo, temos um problema. algum destes campos que você digitou já exite em nosso banco de dados: Username, email, CPF ou RG, Caso você nunca se Registrou, provavelmente seja o Username, tente novamente, Obrigado!"));
      return false;
    }else {
      $cond = $registroService->insereUser($user, $current);
      $_SESSION['usuario'] = $user;
    }


    return $cond;
  }

  public function capturaPost(){
    $cond;
    $user = new User();
    $registroService = new RegistroService();

    $username = fromPost("InpUsername");
    $password = fromPost("InpSenha");
    $confirmPassword = fromPost("InpSenhaConfirm");
    $nome = fromPost("InpNome");
    $email = fromPost("InpEmail");
    $dtnasc = fromPost("InpDtNasc");
    $cpf = fromPost("InpCpf");
    $rg = fromPost("InpRg");
    $endereco = fromPost("InpEndereco");
    $cidade = fromPost("InpCidade");
    $telefone = fromPost("InpTel");
    $estado = fromPost("InpEstado");
    $perfil = fromPost("InpPerfil");
    $sexo = fromPost("InpSexo");

    $user = $registroService->TransformUser($username, $password, $confirmPassword, $nome, $email, $dtnasc, $cpf, $rg, $endereco, $cidade, $telefone, $estado, $perfil, $sexo);
    $cond = $this->registrar($user);

    if ($cond) {
        // return $this->cadMinicurso();
        return "/Home/index";
    }else {
      return "/Registro/index";
    }

  }

  //
  // public function cadMinicurso(){
  //   $registroService = new RegistroService();
  //   $minicursos = $registroService->buscaMinicursos($this->current);
  //
  //   // echo "<script>console.log( 'Debug Objects: " . $p->getTema() . "' );</script>";
  //   $_SESSION['model'] = $minicursos;
  //
  //   $_SESSION['titulo'] = "BearTech Event";
  //
  //   return "/Registro/cadMinicurso";
  //
  // }
  //
  //


}


?>
