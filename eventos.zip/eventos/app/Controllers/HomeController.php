<?php
namespace App\Controllers;

class HomeController {

  public function index(){
    $_SESSION['titulo'] = "BearTech Event";
    return "/Home/index";

  }

}

?>
