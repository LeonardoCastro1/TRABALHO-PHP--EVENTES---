<?php

  namespace App\Services;
  use App\Models\palestra;

  class PalestrasService{



    public function PalestrasList($list)
    {
      $i=0;
      $listaPalestras;
      $qtd = count($list);



      for($i=0;$i<$qtd;$i++) {
        $palestra = new palestra();
        // echo "<script>console.log( 'Debug Objects: " . $list[$i]->tema . "' );</script>";
        $palestra->setData($list[$i]->data);
        $palestra->setDescricao($list[$i]->descricao);
        $palestra->setNome($list[$i]->nome);
        $palestra->setPalestrante($list[$i]->palestrante);
        $palestra->setIdPalestra($list[$i]->id_palestra);
        $palestra->setHorario($list[$i]->horario);
        $listaPalestras[$i] = $palestra;



      }

      return $listaPalestras;

    }


  }



?>
