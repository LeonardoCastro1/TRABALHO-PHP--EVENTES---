<?php

  namespace App\Services;
  use App\Models\minicurso;

  class MinicursoService{



    public function minicursoList($list){
      $i=0;
      $listaMinicurso;
      $qtd = count($list);



      for($i=0;$i<$qtd;$i++) {
        $minicurso = new minicurso();
        // echo "<script>console.log( 'Debug Objects: " . $list[$i]->tema . "' );</script>";

        $minicurso->setData($list[$i]->data);
        $minicurso->setDescricao($list[$i]->descricao);
        $minicurso->setNome($list[$i]->nome);
        $minicurso->setValor($list[$i]->valor);
        $minicurso->setInstrutor($list[$i]->instrutor);
        $minicurso->setQntVagas($list[$i]->qnt_vagas);
        $minicurso->setQntRestante($list[$i]->qnt_restante);
        $minicurso->setHorario($list[$i]->horario);
        $listaMinicurso[$i] = $minicurso;



      }

      return $listaMinicurso;

    }


  }



?>
