<?php

  namespace App\Services;
  use App\Models\User;
  use App\Models\minicurso;
  use App\functions\util;
  use App\Services\MinicursoService;
  use App\Services\Database;

  class RegistroService{

    public function TransformUser($username, $password, $confirmPassword, $nome, $email, $dtnasc, $cpf, $rg, $endereco, $cidade, $telefone, $estado, $perfil, $sexo){
      $user = new User();

      $user->setUsername($username);
      $user->setPassword($password);
      $user->setConfirmPassword($confirmPassword);
      $user->setNome($nome);
      $user->setEmail($email);
      $user->setDtnasc($dtnasc);
      $user->setCpf($cpf);
      $user->setRg($rg);
      $user->setEndereco($endereco);
      $user->setCidade($cidade);
      $user->setTelefone($telefone);
      $user->setEstado($estado);
      $user->setPerfil($perfil);
      $user->setSexo($sexo);

      return $user;
    }


    public function validaUser($user){
      $err="";

      if(!isValid($user->getUsername())){
        $err .= li("Campo Username é Obrigatório");
      }

      if(!isValid($user->getPassword())){
        $err .= li("Senha é Obrigatório");
      }

      if(!isValid($user->getConfirmPassword())){
        $err .= li("Confirmação da Senha é Obrigatório");
      }

      if (strcmp($user->getPassword(), $user->getConfirmPassword()) != 0 ) {
        $err .= li("Senhas São diferentes, Digite a mesma senha.");
      }

      if(!isValid($user->getNome())){
        $err .= li("Campo Nome é Obrigatório");
      }

      if(!isValid($user->getEmail())){
        $err .= li("Campo E-mail é Obrigatório");
      }

      if(!isValid($user->getDtnasc())){
        $err .= li("Campo Data de Nascimento é Obrigatório");
      }

      if(!isValid($user->getCpf())){
        $err .= li("Campo CPF é Obrigatório");
      }

      if (!validaCPF($user->getCpf())) {
        $err .= li("Campo CPF é Invalido");
      }

      if(!isValid($user->getRg())){
        $err .= li("Campo RG é Obrigatório");
      }

      if(!isValid($user->getEndereco())){
        $err .= li("Campo Endereco é Obrigatório");
      }

      if(!isValid($user->getCidade())){
        $err .= li("Campo Cidade é Obrigatório");
      }

      if(!isValid($user->getTelefone())){
        $err .= li("Campo Telefone é Obrigatório");
      }

      if(!isValid($user->getEstado())){
        $err .= li("Campo Estado é Obrigatório");
      }

      if(!isValid($user->getPerfil())){
        $err .= li("Campo Você é? é Obrigatório");
      }

      if(!isValid($user->getSexo())){
        $err .= li("Campo Sexo é Obrigatório");
      }


      if ($err) {
        $_SESSION['erro'] = ul($err);
        return false;
      }else {
        return true;
      }

    }

    public function insereUser($user, $current){
      $resp="";

      $bd = new Database($current);
      $resp= $bd->InsereUser($user);
      return $resp;
    }


    public function verificaExiste($user ,$current){
      $existe = false;
      $username = $user->getUsername();
      $email = $user->getEmail();
      $cpf = $user->getCpf();
      $rg = $user->getRg();

      $bd = new Database($current);
      $lista = $bd->all("usuario");
      $qtd = count($lista);


      for ($i=0 ; $i < $qtd ; $i++ ) {
        if (strcmp($lista[$i]->username,$username) == 0) {
          $existe = true;
        }elseif (strcmp($lista[$i]->email,$email) == 0) {
          $existe = true;
        }elseif(strcmp($lista[$i]->cpf,$cpf) == 0){
          $existe = true;
        }elseif (strcmp($lista[$i]->rg,$rg) == 0) {
          $existe = true;
        }

      }

      return $existe;



    }


    public function buscaMinicursos($current){
      $db = new Database($current);
      $result = $db->all("minicurso");

      $service = new MinicursoService();
      $minicursos = $service->minicursoList($result);
      return $minicursos;
    }

  }

?>
