<?php
namespace App\Services;
use App\Models\User;

class Database {

  private $configuration;

  function __construct($configuration) {
    $this->configuration = $configuration;
  }

  private function connect() {
    $configuration = $this->getConfiguration();

  	$pdo = new \PDO("mysql:host=$configuration->host;dbname=$configuration->database;charset=utf8", "$configuration->user","$configuration->password");
  	$pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
  	$pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_OBJ);

  	return $pdo;
  }

  public function create($table, $fields) {

  	if (!is_array($fields)) {
  		$fields = (array) $fields;
  	}

  	$sql = "insert into {$table}";
  	$sql .= "(" . implode(',', array_keys($fields)) . ")";
  	$sql .= " values(" . ":" . implode(',:', array_keys($fields)) . ")";

  	$pdo = $this->connect();

  	$insert = $pdo->prepare($sql);

  	return $insert->execute($fields);

  }

  public function all($table) {

  	$pdo = $this->connect();

  	$sql = "select * from {$table}";
  	$list = $pdo->query($sql);

  	$list->execute();

  	return $list->fetchAll();

  }

  public function update($table, $fields, $where) {

  	if (!is_array($fields)) {
  		$fields = (array) $fields;
  	}

  	$data = array_map(function ($field) {
  		return "{$field} = :{$field}";
  	}, array_keys($fields));

  	$sql = "update {$table} set ";

  	$sql .= implode(',', $data);

  	$sql .= " where {$where[0]} = :{$where[0]}";

  	$data = array_merge($fields, [$where[0] => $where[1]]);

  	dd($data);

  	$pdo = connect();

  	$update = $pdo->prepare($sql);

  	$update->execute($data);

  	return $update->rowCount();

  }

  public function find($table, $field, $value) {
  	$pdo = connect();

  	$value = filter_var($value, FILTER_SANITIZE_NUMBER_INT);

  	$sql = "select * from {$table} where {$field} = :{$field}";

  	$find = $pdo->prepare($sql);
  	$find->bindValue($field, $value);
  	$find->execute();

  	return $find->fetchAll();
  }

  public function delete($table, $field, $value) {
  	$pdo = connect();

  	$sql = "delete from {$table} where {$field} = :{$field}";
  	$delete = $pdo->prepare($sql);
  	$delete->bindValue($field, $value);

  	return $delete->execute();
  }

    /**
     * Get the value of Configuration
     *
     * @return mixed
     */
    public function getConfiguration()
    {
        return $this->configuration;
    }


    public function InsereUser($user){
      $cond=false;
      $u = new User();
      $u = $user;
      $username = $u->getUsername();
      $password =$u->getPassword();
      $nome = $u->getNome();
      $email = $u->getEmail();
      $dtnasc = $u->getDtnasc();
      $cpf = $u->getCpf();
      $rg = $u->getRg();
      $endereco = $u->getEndereco();
      $cidade = $u->getCidade();
      $telefone = $u->getTelefone();
      $estado = $u->getEstado();
      $perfil = $u->getPerfil();
      $sexo = $u->getSexo();

      $pdo = $this->connect();
      $stmt = $pdo->prepare('INSERT INTO usuario (username, password, nome, email, dtnasc, cpf, rg, endereco, cidade, telefone, estado, perfil, sexo) VALUES(:username, :password, :nome, :email, :dtnasc, :cpf, :rg, :endereco, :cidade, :telefone, :estado, :perfil, :sexo)');
      $cond = $stmt->execute(array(
        ':username' => $username,
        ':password' => $password,
        ':nome' => $nome,
        ':email' => $email,
        ':dtnasc' => $dtnasc,
        ':cpf' => $cpf,
        ':rg' => $rg,
        ':endereco' => $endereco,
        ':cidade' => $cidade,
        ':telefone' => $telefone,
        ':estado' => $estado,
        ':perfil' => $perfil,
        ':sexo' => $sexo
      ));

      return $cond;

    }

}
