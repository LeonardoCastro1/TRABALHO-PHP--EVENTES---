# REQUISITOS

- Sistema gerenciador de eventos.

## Funcionalidades principais
- Apresentação do evento e notícias
- Programação do evento
- Lista de palestras e cursos
- Inscrição para o evento e minicursos/palestras
- Localização do evento
- Formulário de Contato
- Galeria fotos e banner
- Patrocinadores
- Interface de usuário e administrativa
