-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 03/12/2018 às 00:52
-- Versão do servidor: 5.7.24-0ubuntu0.18.04.1
-- Versão do PHP: 7.0.32-4+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projetosite`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `inscricao`
--

CREATE TABLE `inscricao` (
  `id_inscricao` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_minicurso` int(11) NOT NULL,
  `data` date NOT NULL,
  `status_inscricao` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `minicurso`
--

CREATE TABLE `minicurso` (
  `id_minicurso` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `instrutor` varchar(150) NOT NULL,
  `data` date NOT NULL,
  `valor` double NOT NULL,
  `tema` varchar(100) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `qnt_vagas` int(3) NOT NULL,
  `qnt_restante` int(100) NOT NULL,
  `horario` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `minicurso`
--

INSERT INTO `minicurso` (`id_minicurso`, `nome`, `instrutor`, `data`, `valor`, `tema`, `descricao`, `qnt_vagas`, `qnt_restante`, `horario`) VALUES
(1, 'Teste de Minicurso', 'Emanoel Juvencio', '2018-12-20', 40, 'MVC', 'está funcionando', 50, 50, '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `id_pagamento` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `valor` double NOT NULL,
  `dt_venc` date NOT NULL,
  `dt_pag` date DEFAULT NULL,
  `status_pag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `palestra`
--

CREATE TABLE `palestra` (
  `id_palestra` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `palestrante` varchar(150) NOT NULL,
  `data` date NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `horario` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `palestra`
--

INSERT INTO `palestra` (`id_palestra`, `nome`, `palestrante`, `data`, `descricao`, `horario`) VALUES
(3, 'Inovação Tecnologica', 'Emanoel Juvencio', '2018-12-20', 'A palestra visa demonstrar as principais inovações tecnologicas do mercado.', '19:20'),
(4, 'Motivação em Desenvolvimento', 'Fabricio Paschoal', '2018-12-21', 'A palestra visa motivar os alunos que tem aptidao em desenvolvimento de softwares.', '20:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `patrocinador`
--

CREATE TABLE `patrocinador` (
  `id_patrocinador` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `imagem` varchar(500) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dtnasc` date NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `rg` int(15) NOT NULL,
  `endereco` varchar(150) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `telefone` varchar(30) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `perfil` varchar(15) NOT NULL,
  `sexo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `inscricao`
--
ALTER TABLE `inscricao`
  ADD PRIMARY KEY (`id_inscricao`),
  ADD KEY `fk_id_user` (`id_user`),
  ADD KEY `fk_id_minicurso` (`id_minicurso`);

--
-- Índices de tabela `minicurso`
--
ALTER TABLE `minicurso`
  ADD PRIMARY KEY (`id_minicurso`);

--
-- Índices de tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`id_pagamento`),
  ADD KEY `fk_id_user_pag` (`id_user`);

--
-- Índices de tabela `palestra`
--
ALTER TABLE `palestra`
  ADD PRIMARY KEY (`id_palestra`);

--
-- Índices de tabela `patrocinador`
--
ALTER TABLE `patrocinador`
  ADD PRIMARY KEY (`id_patrocinador`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `inscricao`
--
ALTER TABLE `inscricao`
  MODIFY `id_inscricao` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `minicurso`
--
ALTER TABLE `minicurso`
  MODIFY `id_minicurso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `id_pagamento` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `palestra`
--
ALTER TABLE `palestra`
  MODIFY `id_palestra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `patrocinador`
--
ALTER TABLE `patrocinador`
  MODIFY `id_patrocinador` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `inscricao`
--
ALTER TABLE `inscricao`
  ADD CONSTRAINT `fk_id_minicurso` FOREIGN KEY (`id_minicurso`) REFERENCES `minicurso` (`id_minicurso`),
  ADD CONSTRAINT `fk_id_user` FOREIGN KEY (`id_user`) REFERENCES `usuario` (`id_user`);

--
-- Restrições para tabelas `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `fk_id_user_pag` FOREIGN KEY (`id_user`) REFERENCES `usuario` (`id_user`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
