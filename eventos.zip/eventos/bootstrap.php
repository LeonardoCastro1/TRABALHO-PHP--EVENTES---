<?php

  session_start();
  require_once 'vendor/autoload.php';

  use App\Configuration;

  $dev = new Configuration("localhost", "projetosite", "projetosite", "_Projeto123_#");
  $prod = new Configuration("localhost", "a400222_db", "root", "123456");

  $current = $dev;

  //$current = $prod;

 $_SESSION['current']=$current;
